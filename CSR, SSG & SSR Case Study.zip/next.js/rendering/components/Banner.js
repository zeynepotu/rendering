import Link from 'next/link';

export default function Banner({ title, type }) {
  return (
    <div className="banner">
      <h1>{title}</h1>
      <p>Rendering: {type}</p>
      <Link href="/">
        <a className="btn">Geri Dön</a>
      </Link>
    </div>
  );
}
