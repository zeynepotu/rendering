import { useState, useEffect } from 'react';
import Banner from '../../components/Banner';
import { getPost } from '../../lib/posts';

export default function Post() {
  const [post, setPost] = useState(null);

  useEffect(() => {
    async function fetchPost() {
      const post = await getPost('postId');
      setPost(post);
    }
    fetchPost();
  }, []);

  return (
    <div className="container">
      {post ? <Banner title={post.title} type="CSR" /> : null}
      {post ? (
        <>
          <h1>{post.title}</h1>
          <p>{post.body}</p>
        </>
      ) : (
        <p>Yükleniyor...</p>
      )}
    </div>
  );
}
