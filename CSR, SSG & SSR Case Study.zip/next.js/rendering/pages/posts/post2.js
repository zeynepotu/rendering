import Banner from '../../components/Banner';
import { getPost } from '../../lib/posts';

export default function Post({ post }) {
  return (
    <div className="container">
      <Banner title={post.title} type="SSR" />
      <h1>{post.title}</h1>
      <p>{post.body}</p>
    </div>
  );
}

export async function getServerSideProps({ params }) {
  const post = await getPost(params.postId);
  return {
    props: {
      post,
    },
  };
}
